const Discord = require('discord.js');

exports.run = async (client, message, args) => {

let embed = new Discord.MessageEmbed() 
  .setColor('334b80') 
  .setTitle(`#334B80`) 
  .setImage(https://www.htmlcsscolor.com/preview/gallery/334B80.png)
 await message.channel.send(embed); 
};