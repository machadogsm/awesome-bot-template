module.exports.run = async (client, message, args) => {
  const m = await message.channel.send('<:ZeroTwo_heartlove:849728243120340992>');

  m.edit(`<@477641226829692932> <:ZeroTwo_heartlove:849728243120340992>`
  );
};